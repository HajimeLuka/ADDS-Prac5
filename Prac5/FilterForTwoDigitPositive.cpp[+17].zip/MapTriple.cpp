#include <iostream>
#include "MapTriple.h"

using namespace std;

MapTriple::MapTriple():MapGeneric(){

}

int MapTriple::f(int input){
    return input*3;
}